#include <iostream>

int N, M;
const int MXR = 1000;
const int MXC = 1000;
const int MX = 1000005;

struct Elem
{
	int gid;
	int value;
	int num;
	int with[6];
	int fwith;
} info[MX + 1];

int mat[MXR + 1][MXC + 1];
int parent[MX + 1];
int mark[MX + 1];

int find(int i) { while (parent[i]) i = parent[i]; return i; }
void my_union(int i, int j) { if (i == j) return; parent[i] = j; info[j].num += info[i].num; }
int index(int i, int j) { return (i*M) + j + 1; };

int solve()
{
	for (int i = 0; i < N; ++i)
	for (int j = 0; j < M; ++j)
	{
		info[index(i, j)].value = mat[i][j];
		info[index(i, j)].gid = index(i, j);
		info[index(i, j)].num = 1;
		if ((i - 1) >= 0 && mat[i - 1][j] == mat[i][j])
			my_union(find(index(i - 1, j)), find(index(i, j)));
		if ((j - 1) >= 0 && mat[i][j - 1] == mat[i][j])
			my_union(find(index(i, j - 1)), find(index(i, j)));
	}

	int cnt = 0;
	for (int i = 1; i <= N*M; ++i)
	{
		if (!parent[i])
			++cnt;
	}

	for (int i = 1; i <= N*M; ++i)
	{
		if (!parent[i] && !info[i].value)
		{
			int gid = info[i].gid;
			for (int j = 0; j <= N*M; ++j)
				mark[j] = false;
			mark[gid] = true;
			for (int j = 0; j < N; ++j)
			for (int k = 0; k < M; ++k)
			{
				int zg = find(index(j, k));
				if (info[zg].gid == gid)
				{
					int wg;
					if (j - 1 >= 0)
					{
						wg = find(index(j - 1, k));
						if (!mark[info[wg].gid]) { info[zg].with[info[wg].value] += info[wg].num; mark[info[wg].gid] = true; }
					}
					if (k - 1 >= 0)
					{
						wg = find(index(j, k - 1));
						if (!mark[info[wg].gid]) { info[zg].with[info[wg].value] += info[wg].num; mark[info[wg].gid] = true; }
					}
					if (j + 1 < N)
					{
						wg = find(index(j + 1, k));
						if (!mark[info[wg].gid]) { info[zg].with[info[wg].value] += info[wg].num; mark[info[wg].gid] = true; }
					}
					if (k + 1 < M)
					{
						wg = find(index(j, k + 1));
						if (!mark[info[wg].gid]) { info[zg].with[info[wg].value] += info[wg].num; mark[info[wg].gid] = true; }
					}
				}
			}
		}
	}

	for (int i = 1; i <= N*M; ++i)
	{
		if (!parent[i] && !info[i].value)
		{
			int mx = info[i].with[1];
			info[i].fwith = 1;
			for (int j = 2; j <= 5; ++j)
			if (info[i].with[j] >= mx)
			{
				mx = info[i].with[j];
				info[i].fwith = j;
			}
			int gid = info[i].gid;

			for (int j = 0; j < N; ++j)
			for (int k = 0; k < M; ++k)
			{
				int zg = find(index(j, k));
				if (info[zg].gid == gid)
				{
					mat[j][k] = info[i].fwith;
				}
			}
		}
	}

	cnt = 0;
	for (int i = 1; i <= N*M; ++i) parent[i] = 0;

	for (int i = 0; i < N; ++i)
	for (int j = 0; j < M; ++j)
	{
		if ((i - 1) >= 0 && mat[i - 1][j] == mat[i][j])
			my_union(find(index(i - 1, j)), find(index(i, j)));
		if ((j - 1) >= 0 && mat[i][j - 1] == mat[i][j])
			my_union(find(index(i, j - 1)), find(index(i, j)));
	}

	for (int i = 1; i <= N*M; ++i)
	{
		if (!parent[i])
			++cnt;
	}

	return cnt;
}

int main()
{
	std::cin >> N >> M;
	for (int i = 0; i < N; ++i)
	for (int j = 0; j < M; ++j)
		std::cin >> mat[i][j];
	std::cout << solve() << std::endl;
	return 0;
}