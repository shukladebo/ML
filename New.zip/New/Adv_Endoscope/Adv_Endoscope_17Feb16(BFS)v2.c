/* Endoscope Advance Test on 16 Feb 2016 by Sasikumar using BFS*/
#include <stdio.h>

#define myprintf //printf   
#define UP R-1
#define DOWN R+1
#define LEFT C-1
#define RIGHT C+1
#define SameROW R
#define SameCOL C

#define CURR_PIPE(CurrCell,P1,P2,P3, P4) (CurrCell==P1 || CurrCell==P2 || CurrCell==P3 || CurrCell==P4 ) 
#define NEXT_PIPE(CurrCell,P1,P2,P3, P4) (CurrCell==P1 || CurrCell==P2 || CurrCell==P3 || CurrCell==P4 ) 

int N=0, M=0, R=0, C=0, L=0;
int Matrix[51][51]={0,};
int vmat[51][51]={0,};	//visited matrix
int T=0, Answer=0;
int tc_idx, i,j;

int front=0, rear=0, Qx[3000], Qy[3000],Ql[3000];


int BFS ();
int printmatrix();
int clearmatrix();

int Enqueue(int x, int y, int L)
{
	Qx[rear]=x; Qy[rear]=y; Ql[rear]=L; rear++;
	Answer++;
	vmat[x][y]=1;
	myprintf("\nEnqueue[%d,%d]=%d-",x,y,Matrix[x][y]);
}
int Dequeue(int* x,int *y, int *l)
{
	*x=Qx[front]; *y=Qy[front]; *l=Ql[front]; front++;
}
int IsQueueEmpty()
{
	if (front == rear ) return 1; else return 0;
}
int printqueue();

main()
{
	scanf("%d", &T);
	
	for( tc_idx = 0; tc_idx < T; tc_idx++)
	{
		scanf("%d", &N);
		scanf("%d", &M);
		scanf("%d", &R);
		scanf("%d", &C);
		scanf("%d", &L);		
		
		myprintf("BFS NxM=%dx%d, (R,C)=(%d,%d) , Endoscope Length=%d\n",N, M,R,C,L);
		
		if ( N < 5 || N > 50 ||  M < 5 || M > 50 || R < 0 || R > N-1 || C < 0 || C > M-1  )
			Answer = 0;
		else if ( L == 0)
			Answer = 0;

			for(i=0;i<N;i++)
				for(j=0;j<M;j++)
					scanf("%d", &Matrix[i][j]);
			printmatrix();
			
			if (Matrix[R][C]==0)
				Answer =0;
			else 
			{ 
				Enqueue(R,C,L-1);
				printqueue();
				BFS();
			}

		 	
		printf("\n#%d %d\n", tc_idx+1, Answer);
		clearmatrix();
	}
}


BFS()
{
	int R, C;
	
	if ( IsQueueEmpty() )
		return;

	Dequeue(&R, &C, &L);  myprintf("\ndequeue ~%d,%d[%d] L=%d  ~  ",R,C,Matrix[R][C], L);
	printqueue();
/*	if (!vmat[R][C])
	{
		vmat[R][C]=1;
		Answer++;
		myprintf("Matrix[%d][%d]=%d  - ",R, C, Matrix[R][C]);
	}
	else
		return;
*/	
	
	if ( CURR_PIPE(Matrix[R][C],1,2,4,7) &&  NEXT_PIPE(Matrix[UP][C],1,2,5,6) && !vmat[UP][C] && UP >=0 && L-1 >=0 ) Enqueue(UP,SameCOL,L-1);     //(UP, SameCOL, L-1);
	if ( CURR_PIPE(Matrix[R][C],1,2,5,6) &&  NEXT_PIPE(Matrix[DOWN][C],1,2,4,7) && !vmat[DOWN][C] && DOWN <51 && L-1 >=0 ) Enqueue(DOWN,SameCOL,L-1);
	if ( CURR_PIPE(Matrix[R][C],1,3,6,7) &&  NEXT_PIPE(Matrix[R][LEFT],1,3,4,5) && !vmat[R][LEFT] && LEFT >=0 && L-1 >=0 ) Enqueue(SameROW,LEFT,L-1);
	if ( CURR_PIPE(Matrix[R][C],1,3,4,5) &&  NEXT_PIPE(Matrix[R][RIGHT],1,3,6,7) && !vmat[R][RIGHT] && RIGHT <51 && L-1 >=0 ) Enqueue(SameROW,RIGHT,L-1);	
	
	BFS();
}

printmatrix()
{
	int x, y;
	for(x=0;x<N;x++)
	{
		for(y=0;y<M;y++)
			myprintf("%d ", Matrix[x][y]);
		myprintf("\n");
	}
}

clearmatrix()
{
	int x, y;
	for(x=0;x<N;x++)
		for(y=0;y<M;y++)
			Matrix[x][y]=vmat[x][y]=0;
	Answer=0;
}
printqueue()
{
	for (i=front; i < rear; i++)
	{
		myprintf("f=%d,r=%d{%d,%d} ",front, rear, Qx[i],Qy[i]);
	}
	myprintf("\n");
}
