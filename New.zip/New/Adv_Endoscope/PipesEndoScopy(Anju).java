import java.util.Scanner;

public class PipesEndoScopy {

	static int N,M;
	static int[][] arr, dup,lengtharr;
	static boolean vis[][];
	static int count;



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int T, test_case,x,y,l;
//		  try {
//			System.setIn(new FileInputStream("E:\\Eclipse_EE\\MC\\practise\\src\\sample_input.txt"));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Scanner sc = new Scanner(System.in);

		T = sc.nextInt();
		for(test_case = 0; test_case < T; test_case++)
		{
			count=0;
			N = sc.nextInt();
			M = sc.nextInt();

			x = sc.nextInt();
			y = sc.nextInt();

			l = sc.nextInt();

			arr = new int[N][M];
			dup = new int[N][M];
			vis = new boolean[N][M] ;
			lengtharr = new int[N][M];

			//Read input
			for(int i=0;i<N;i++)
			{
				for(int j=0;j<M;j++)
				{
					arr[i][j] = dup[i][j] = sc.nextInt();
					vis[i][j] =false;
					lengtharr[i][j] =-1;
				}
			}	
			traverse(x,y,l);
			//printing input

			/*for(int i=0;i<N;i++)
	        	{
	        		for(int j=0;j<M;j++)
	        		{
	        			System.out.print(arr[i][j]+"  ");
	        		}
	        		System.out.println("");
	        	}

	        	for(int i=0;i<N;i++)
	        	{
	        		for(int j=0;j<M;j++)
	        		{
	        			System.out.print(vis[i][j]+"  ");
	        		}
	        		System.out.println("");
	        	}*/
			//printing total blocks
			System.out.println("#"+(test_case+1)+" "+count);
		}
	}

	private static void traverse(int x, int y, int i) {
		// TODO Auto-generated method stub
		int val = dup[x][y];
		if(isSafe(x,y,i,val))
		{
			if(!vis[x][y])
			{
				vis[x][y]=true;
				count++;
//				lengtharr[x][y] = i;
			}
			int len = i-1;

			arr[x][y]=0;
			//traverse right
			if(val == 1 || val == 3 || val ==4 || val ==5)
				if(isSafe(x,y+1,i,val) && (dup[x][y+1] == 1 || dup[x][y+1] == 3 || dup[x][y+1] == 6 || dup[x][y+1] == 7) && i>lengtharr[x][y+1])
					{
						lengtharr[x][y] = i;
						traverse(x,(y+1),len);
					}
			//traverse left
			if(val == 1 || val == 3 || val ==6 || val ==7)
				if(isSafe(x,y-1,i,val) && (dup[x][y-1] == 1 || dup[x][y-1] == 3 || dup[x][y-1] == 4 || dup[x][y-1] == 5)&& i>lengtharr[x][y-1])
					{lengtharr[x][y] = i;
					traverse(x,(y-1),len);
					}
			//traverse up
			if(val == 1 || val == 2 || val ==4 || val ==7)
				if(isSafe(x-1,y,i,val) && (dup[x-1][y] == 1 || dup[x-1][y] == 2 || dup[x-1][y] == 5 || dup[x-1][y] == 6)&& i>lengtharr[x-1][y])
					{lengtharr[x][y] = i;
					traverse(x-1,y,len);
					}
			//traverse down
			if(val == 1 || val == 2 || val ==5|| val ==6)
				if(isSafe(x+1,y,i,val) && (dup[x+1][y] == 1 || dup[x+1][y] == 2 || dup[x+1][y] == 4 || dup[x+1][y] == 7)&& i>lengtharr[x+1][y])			
					{lengtharr[x][y] = i;
					traverse(x+1,y,len);
					}
		}
	}

	private static boolean isSafe(int x, int y, int i,int currentvalue) {
		// TODO Auto-generated method stub
		if(x>=0 && x<N && y>=0 && y<M && i>0 && dup[x][y]!=0)
			return true;
		return false;
	}
}
