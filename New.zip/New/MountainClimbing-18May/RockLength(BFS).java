Problem:
Mr. Kim is very good at climbing rocks, rocks are represented by 1 and spaces are represented by 0, all cells in the ground level contains 1,
bottom left cell is always the src and is represented by 2, destination can be anywhere and is represented by 3
he can move up down & left right,In horizontal direction Kim cant skip rocks however vertical direction he can.

Solution(BFS):

import java.util.Scanner;

public class RockLength {

	static int N,M,r,c,level,flag,front,rear;
	static int C[][] ,V[][];
	static Queue q[];

	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		//Number of Testcases
		int T = sc.nextInt();

		for(int testCase = 1;testCase <= T;testCase++){

			N = sc.nextInt(); //Height of the rock
			M = sc.nextInt(); //Width of the rock
			C = new int[N+1][M+1]; //Rock data			
			level = 0; 
			flag = 0;

			//Reading rock data  
			for(int i = 1;i <= N;i++){
				for(int j = 1;j <= M;j++){
					C[i][j] = sc.nextInt();
					if(C[i][j] == 2){
						r = i;
						c = j;
					}
				}
			}

			for(int k = 1;k <= N;k++){
				if(flag == 0){
					V = new int[N+1][M+1]; // re-intializing visited and queue data for every level
					q = new Queue[2*N*M];
					level = k;
					front = 0;
					rear = -1;
					computeRockLength();  
				}else{
					System.out.println("#"+" "+testCase+" "+level);
					break;
				}
			}			
		}		
	}

	private static void computeRockLength() {

		q[++rear] = new Queue(r, c);  //insert(push) element into queue

		while(front <= rear){
			Queue obj = q[front++];   //delete(pop) element from the queue
			int u = obj.row_Coordinate;
			int v = obj.col_Coordinate;
			if(C[u][v] == 3){        //if reached the destination ,set the flag and break the loop
				flag = 1;
				break;
			}else{
				//Checking down
				if(isValid(u+level,v)){           
					q[++rear] = new Queue(u+level, v);
					V[u+level][v] = 1;
				}else{
					int newLevel = level-1;
					while(newLevel>=1){
						if(isValid(u+newLevel,v)){
							q[++rear] = new Queue(u+newLevel, v);
							V[u+newLevel][v] = 1;
							break;
						}
						else{
							newLevel--;
						}
					}
				}
				//Checking up
				if(isValid(u-level,v)){
					q[++rear] = new Queue(u-level, v);
					V[u-level][v] = 1;
				}else{
					int newLevel = level-1;
					while(newLevel>=1){
						if(isValid(u-newLevel,v)){
							q[++rear] = new Queue(u-newLevel, v);
							V[u-newLevel][v] = 1;
							break;
						}
						else{
							newLevel--;
						}
					}
				}

				//Checking right
				if(isValid(u,v+1)){
					q[++rear] = new Queue(u,v+1);
					V[u][v+1] = 1;
				}

				//Checking left
				if(isValid(u,v-1)){
					q[++rear] = new Queue(u, v-1);
					V[u][v-1] = 1;
				}

			}
		}

	}

	private static boolean isValid(int u, int v) {
		return (u>0 && u<=N && v>0 && v<=M && V[u][v]==0 && C[u][v]!=0);
	}

}


class Queue{
	int row_Coordinate;
	int col_Coordinate;
	public Queue(int row_Coordinate,int col_Coordinate) {
		this.row_Coordinate = row_Coordinate;
		this.col_Coordinate = col_Coordinate;		
	}
}


INPUT:

2
5 8
1 1 1 1 0 0 0 0
0 0 0 3 0 1 1 1 
1 1 1 0 0 1 0 0
0 0 0 0 0 0 1 0
2 1 1 1 1 1 1 1
5 6
0 1 1 1 0 0
3 1 0 1 1 0
0 0 0 0 1 1
0 0 0 0 0 1
2 1 1 1 1 1

OUTPUT:

#Case 1
2
#Case 2
1

