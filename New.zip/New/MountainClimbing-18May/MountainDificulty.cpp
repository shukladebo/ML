#include <iostream>
#define MAX 55

using namespace std;

struct  indx
{
	int x, y;
};
int mat[MAX][MAX];
bool visited[MAX][MAX];

indx Q[MAX*MAX];
int f, r,N,M;

void push(int x, int y){
		Q[r++] = { x, y };
}

indx pop(){

	return Q[f++];
}

bool isEmpty(){
	return (f == r);
}

bool isSafe(int x, int y){

	if (x >= 0 && x<N && y >= 0 && y<M && mat[x][y]!=0)
		return true;
	return false;
}

void clear(){
	
	for (int i = 0; i < N; i++){
		for (int j = 0; j < M; j++)
			visited[i][j] = false;
	}
	f = r = 0;
}

int bfs(int x, int y, int height){

	visited[x][y] = true;

	push(x, y);

	while (!isEmpty()){

		indx temp = pop();
		int i = temp.x;
		int j = temp.y;

		if (mat[i][j] == 3)
			return height;

		if (isSafe(i, j - 1) && !visited[i][j - 1]){
			visited[i][j - 1] = true;
			push(i, j - 1);
		}

		if (isSafe(i, j + 1) && !visited[i][j + 1]){
			visited[i][j + 1] = true;
			push(i, j + 1);
		}

		for (int k = 1; k <= height; k++){
			if (isSafe(i+k, j) && !visited[i+k][j]){
				visited[i+k][j] = true;
				push(i+k, j);
			}
			if (isSafe(i - k, j) && !visited[i - k][j]){
				visited[i - k][j] = true;
				push(i - k, j);
			}
		}
	}
	return 0;
}

int main(){
	int T, res = 0;

	cin >> T;
	for (int test = 1; test <= T; test++){
		cin >> N >> M;
		for (int i = 0; i < N; i++){
			for (int j = 0; j < M; j++)
				cin >> mat[i][j];
		}

		for (int l = 1; l < N; l++){
			clear();
			res = 0;
			res = bfs(N - 1, 0, l);

			if (res>0)
				break;
		}
		cout << "#" << test << " " << res << endl;
	}
	return 0;
}