
Mr. Kim is very good at climbing rocks, rocks are represented by 1 and spaces are represented by 0, all cells in the ground level contains 1,
bottom left cell is always the src and is represented by 2, destination can be anywhere and is represented by 3
he can move up down & left right,In horizontal direction Kim cant skip rocks however vertical direction he can.


import java.util.Scanner;
import java.util.Stack;

public class RockClimbing {

	static Node[][] input;
	static int rows;
	static int cols;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for (int test = 0; test < T; test++) {
			rows = sc.nextInt(); // 1 <= H <= 50
			cols = sc.nextInt(); // 1 <= W <= 50

			input = new Node[rows][cols];

			// src is always the bottom left cell and the ground floor cells are
			// always 1 except src
			// src is denoted by 2
			// dst id denoted by 3
			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					int data = sc.nextInt();
					input[i][j] = new Node(data, i, j);
				}
				//sc.nextLine();
			}

			int answer = 0;

			for (int i = 1; i <= rows; i++) {
				clearVisited();
				boolean result = dfs(input[rows - 1][0], i);
				if (result) {
					answer = i;
					break;
				}
			}

			System.out.println("#" + (test + 1) + " " + answer);
		}

		sc.close();
	}

	private static boolean dfs(Node src, int level) {
		Stack<Node> st = new Stack<Node>();
		st.push(src);
		src.visited = true;

		while (!st.isEmpty()) {
			Node parent = st.pop();
			
			int curRow = parent.row;
			int curCol = parent.col;
			int curLevel = 0;
			
			
			// up
			for (int i = curRow - 1; i >= 0 && curLevel < level; i--, curLevel++) {
				if (input[i][curCol].data >= 1 && !input[i][curCol].visited) {
					
					if(Visit(input[i][curCol], st)){
						return true;
					}
				}
			}

			curLevel = 0;

			// down
			for (int i = curRow + 1; i < rows && curLevel < level; i++, curLevel++) {
				if (input[i][curCol].data >= 1 && !input[i][curCol].visited) {
					if(Visit(input[i][curCol], st)){
						return true;
					}
				}
			}

			// right
			if (curCol + 1 < cols && input[curRow][curCol + 1].data >= 1 && !input[curRow][curCol + 1].visited) {
				if(Visit(input[curRow][curCol + 1], st)){
					return true;
				}
			}

			// left
			if (curCol - 1 >= 0 && input[curRow][curCol - 1].data >= 1 && !input[curRow][curCol - 1].visited) {
				if(Visit(input[curRow][curCol - 1], st)){
					return true;
				}
			}
		}
		return false;
	}

	private static boolean Visit(Node child,Stack<Node> st) {
	
		
			if (child.data == 3) {
				return true;
			}
			st.push(child);
			child.visited = true;
		
		return false;
	}

	private static void clearVisited() {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				input[i][j].visited = false;
			}
		}
	}

}

class Node {
	int data;
	int row;
	int col;
	boolean visited;

	public Node(int data, int row, int col) {
		this.data = data;
		this.row = row;
		this.col = col;
		this.visited = false;
	}
}



2
5 8
1 1 1 1 0 0 0 0
0 0 0 3 0 1 1 1 
1 1 1 0 0 1 0 0
0 0 0 0 0 0 1 0
2 1 1 1 1 1 1 1
5 6
0 1 1 1 0 0
3 1 0 1 1 0
0 0 0 0 1 1
0 0 0 0 0 1
2 1 1 1 1 1

#Case 1
2
#Case 2
1

