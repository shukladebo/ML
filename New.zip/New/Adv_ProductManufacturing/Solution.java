import java.util.Scanner;


public class Solution {
	int D,E,F,d,e,N;
	int model_mat[][];
	int max_model[];
	int process()
	{
		int max=0;
		/* Instead of 3 for loops below, use a method to find combinations of N models selected 3 at a time and call the 
		 compute method with the each combination*/
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				for(int k=0;k<N;k++)
				{
					int value=compute(i,j,k);
					if(value>max)
						max=value;
				}
			}
		}
		return max;
	}
int compute(int a,int b,int c)
{
	int val=0;
	for(int i=0;i<=max_model[a];i++)
	{
		for(int j=0;j<=max_model[b];j++)
		{
			for(int k=0;k<=max_model[c];k++)
			{
				int cost=check(a,b,c,i,j,k);
				if(cost>val)
				val=cost;
			}
		}
	}
	return val;
}
int check(int a,int b,int c,int i,int j,int k)
{
	int retVal=0;
	
	if(((model_mat[a][0]*i)+(model_mat[b][0]*j)+(model_mat[c][0]*k))>D||
			((model_mat[a][1]*i)+(model_mat[b][1]*j)+(model_mat[c][1]*k))>E
		||((model_mat[a][2]*i)+(model_mat[b][2]*j)+(model_mat[c][2]*k))>F)
		{
			
			return 0;
		}
	else
	{
		int remCpu=D-((model_mat[a][0]*i)+(model_mat[b][0]*j)+(model_mat[c][0]*k));
		int remMem=E-((model_mat[a][1]*i)+(model_mat[b][1]*j)+(model_mat[c][1]*k));
		retVal=((model_mat[a][3]*i)+(model_mat[b][3]*j)+(model_mat[c][3]*k)+(remCpu*d)+(remMem*e));
	}
	
	return retVal;
	
}
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	int T=sc.nextInt();
	for(int testcase=1;testcase<=T;testcase++)
	{
		Solution sl=new Solution();
		sl.D=sc.nextInt();
		sl.E=sc.nextInt();
		sl.F=sc.nextInt();
		sl.d=sc.nextInt();
		sl.e=sc.nextInt();
		sl.N=sc.nextInt();
		sl.model_mat=new int[sl.N][4];
		sl.max_model=new int[sl.N];
		for(int i=0;i<sl.N;i++)
		{
			for(int j=0;j<4;j++)
			{
				sl.model_mat[i][j]=sc.nextInt();
			}
		}

		for(int i=0;i<sl.N;i++)
		{
			int x=sl.D/sl.model_mat[i][0];
			int y=sl.E/sl.model_mat[i][1];
			int z=sl.F/sl.model_mat[i][2];
			if(x<y && x<z)
				sl.max_model[i]=x;
			else if(y<x && y<z)
			    sl.max_model[i]=y;
			else 
				sl.max_model[i]=z;
		}
		
		System.out.println("#"+testcase+" "+sl.process());
	}
}
}
