/***********************************************************
* You can use all the programs on  www.c-program-example.com
* for personal and learning purposes. For permissions to use the
* programs for commercial purposes,
* contact info@c-program-example.com
* To find more C programs, do visit www.c-program-example.com
* and browse!
* 
*                      Happy Coding
***********************************************************/
 
#include "stdio.h"
#include "conio.h"
#define infinity 999
//int N;
int n,v,i,j,cost[10][10],dist[10];
int u,count,w,flag[10],min;

void dij(int n,int v,int cost[10][10],int dist[])
{
//int i,u,count,w,flag[10],min;

 for(i=1;i<=n;i++)
  flag[i]=0,dist[i]=cost[v][i];
 count=2;
 while(count<=n)
 {
  min=99;
  for(w=1;w<=n;w++)
   if(dist[w]<min && !flag[w])
    min=dist[w],u=w;
  flag[u]=1;
  printdist_flag();  printf("u=%d, w=%d count=%d\n",u,w,count+1);
  count++;
  for(w=1;w<=n;w++)
   if((dist[u]+cost[u][w]<dist[w]) && !flag[w])
    dist[w]=dist[u]+cost[u][w];
   printdist_flag();  printf("(2)u=%d, w=%d count=%d\n",u,w,count+1);
}
}

printdist_flag()
{
	int i;
	printf("\ndist[]=");
	for (i=1; i <= n; i++) printf("%d ",dist[i]);
	printf("\nflag[]=");
	for (i=1; i <= n; i++) printf("%d ",flag[i]);
	
}


void main()
{
// clrscr();
 freopen("Dijkstras_input.txt","r",stdin);
 printf("\n Enter the number of nodes:");
 scanf("%d",&n);
 printf("\n Enter the cost matrix:\n");
 for(i=1;i<=n;i++)
  {
  for(j=1;j<=n;j++)
  {
   scanf("%d",&cost[i][j]); printf("%d ",cost[i][j]);
   if(cost[i][j]==0)
    cost[i][j]=infinity;
  } printf("\n");
  }
 printf("\n Enter the source node starting from:");
 scanf("%d",&v);  printf("%d\n",v);
 //N=n;
 dij(n,v,cost,dist);
 printf("\n Shortest path:\n");
 for(i=1;i<=n;i++)
  if(i!=v)
   printf("%d->%d,cost=%d\n",v,i,dist[i]);
 getch();
}
