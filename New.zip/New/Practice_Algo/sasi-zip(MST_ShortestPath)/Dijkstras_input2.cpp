5
0	10	3	0	0
0	0	1	2	0
0	4	0	8	2
0	0	0	0	7
0	0	0	9	0
1



 Shortest path:
1->2,cost=7
1->3,cost=3
1->4,cost=9
1->5,cost=5
