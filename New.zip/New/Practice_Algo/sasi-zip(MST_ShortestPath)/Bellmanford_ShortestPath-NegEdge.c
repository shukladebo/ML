#include <stdio.h>
int cost[11][11];
int dist[11];
int pi[11];
int n, v, ne;
typedef struct 
{
	int x;
	int y;
	int c;
} edge;
edge cn[11*11]; 
setcn(edge *n, int s, int e, int cost) {
	n->x=s; n->y=e; n->c=cost;
	
}

int i, j, k , flg;

#define dprint printf
main()
{
	freopen("bellman_input.txt","r",stdin);
	
	scanf("%d",&n); dprint("%d\n",n);
	
	for(i=1, k=1; i<= n; i++)
	{   
		for (j=1; j<=n; j++)
			{
			scanf("%d", &cost[i][j]);  
			if(cost[i][j]!=0) setcn(&cn[k++] ,i, j, cost[i][j]);
			//if(cost[i][j]==0) cost[i][j]=99 ; 
			dprint("%2d ",cost[i][j]);
			}
		dprint("\n");
	}
	ne=k-1; dprint("ne=%d ",ne); printcn();
	
	for(k=1; k<=n ; k++) 	{ dist[k]=99; pi[k]=-1; }
	for(k=1; k <= n; k++)
	{
		flg=0;
		dist[1]=0; pi[1]=-1;
		for(i=1; i <= ne; i++)
		{	//printf(" (%d-%d,c=%d) ",cn[i].x,cn[i].y,cn[i].c);
			printf("\ndist[%d]=%2d, C=%2d, dist[%d]=%2d  ",cn[i].x , dist[ cn[i].x ], cn[i].c, cn[i].y, dist[ cn[i].y] );


			if ( dist[ cn[i].x ]!=99 && ((dist[ cn[i].x ]+cn[i].c ) < dist[ cn[i].y ] ))
				{ 
					flg=1;
					dist[cn[i].y] = dist[ cn[i].x ]+cn[i].c;
				  	pi[cn[i].y] = cn[i].x;
				}
		}
		printdist_pi();
		if(flg==0) break;
	}
	
	printf("\nShortest Path - Bellman ford -ve Edges");
	for(i=1; i<=n; i++)
		printf("\nCost from 1->%d = %d", i,dist[i]);
}

printdist_pi()
{
	int i;
	printf("\ndist[]=");
	for (i=1; i <= n; i++) printf("%2d ",dist[i]);
	printf("\npi[]  =");
	for (i=1; i <= n; i++) printf("%2d ",pi[i]);
	printf("\n");
}

printcn()
{
	int i;
	printf("\ncn[]=");
	for (i=1; i <= ne; i++) printf(" (%d-%d,c=%d) ",cn[i].x,cn[i].y,cn[i].c);
}
