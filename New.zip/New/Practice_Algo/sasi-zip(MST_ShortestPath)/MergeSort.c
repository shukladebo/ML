#include <stdio.h>
#define myprintf //printf
#define MAX 1000

//int arr[]={2,4,1,6,8,5,3,7,9};

int arr[MAX], N;
int arrsize;


printarr()
{
	int i;
	for(i=0;i<arrsize;i++)
		printf("%d ", arr[i]);
		
	printf("\n");
}
print_array(int a[],int sz)
{
	int i;
	printf("sort->");
	for(i=0;i<sz;i++)
		printf("%d ", a[i]);
		
	printf("\n");
}
mergesort(int a[],int size)
{
	int mid,i,j;
	int leftarr[MAX], rightarr[MAX];
	if (size < 2) return;
	mid = size/2; 
//	left=start; right=mid+1; leftsize=mid+1; rightsize=end-mid;
	for (i=0; i < mid;i++) leftarr[i]=a[i];
	for (i=mid,j=0; i < size;i++,j++) rightarr[j]=a[i];
	myprintf("\n leftarr (%d,%d,%d) rightarr \n", 0,mid,size );
	print_array(leftarr,mid);
	print_array(rightarr,size-mid);
	
	mergesort(leftarr,mid);
	mergesort(rightarr,size-mid);
//	printf("a=%ld\n", a);
	merge(a,leftarr,rightarr,mid, size-mid);
	
}

merge(int a[],int leftarr[],int rightarr[],int leftsize, int rightsize)
{

	int i=0, j=0,k=0, temp;
	
	while ( i < leftsize && j <rightsize)
	{
		if(leftarr[i] < rightarr[j])
		{
			a[k++]=leftarr[i++]; 
		}
		else
		{
			a[k++]=rightarr[j++];
		}
	}
	
	while (i < leftsize)  a[k++]=leftarr[i++];
	while (j < rightsize) a[k++]=rightarr[j++];
	myprintf("merge left right --> ");
	print_array(a,leftsize+rightsize);
//	printf("a=%ld , arr=%ld\n", a, arr);
//	printarr();
}
reinitialize()
{
	memset(arr,0,MAX);
	arrsize=0;
}
main()
{
	int i, tc, T;
	freopen("mergesort_input.txt","r",stdin);
	scanf("%d",&T);
	for(tc=1; tc <= T; tc++)
	{
	
	scanf("%d",&N); arrsize=N;
	for(i=0;i<N;i++) scanf("%d",&arr[i] );
	
	printf("TC#%d\n", tc);
	printarr();
//	start = 0; end=len-1;
//	printf("arr=%ld\n", arr);
	mergesort(arr,arrsize);
	
	printarr();
	reinitialize();
   }
	
}

